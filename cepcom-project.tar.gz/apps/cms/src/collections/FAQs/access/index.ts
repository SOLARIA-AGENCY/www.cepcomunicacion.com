/**
 * FAQs Collection - Access Control Exports
 */

export { canCreateFAQ } from './canCreateFAQ';
export { canReadFAQs } from './canReadFAQs';
export { canUpdateFAQ } from './canUpdateFAQ';
export { canDeleteFAQ } from './canDeleteFAQ';
