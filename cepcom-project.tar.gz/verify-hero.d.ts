export {};
//# sourceMappingURL=verify-hero.d.ts.map