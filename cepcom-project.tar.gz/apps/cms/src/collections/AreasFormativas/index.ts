export * from './AreasFormativas';
