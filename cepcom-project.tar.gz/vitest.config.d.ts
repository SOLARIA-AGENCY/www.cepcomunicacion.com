declare const _default: import("vite").UserConfig;
export default _default;
//# sourceMappingURL=vitest.config.d.ts.map