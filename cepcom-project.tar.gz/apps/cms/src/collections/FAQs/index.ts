/**
 * FAQs Collection - Main Export
 */

export { FAQs } from './FAQs';
export * from './FAQs.validation';
export * from './access';
export * from './hooks';
